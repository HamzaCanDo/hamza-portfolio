<?php

$hostname = "http://localhost/news-site";

$conn = mysqli_connect("sql101.infinityfree.com", "if0_40863722", "hamza121173", "if0_40863722_shopping_db");
if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}

