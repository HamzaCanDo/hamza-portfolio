<?php 
set_time_limit(30);
session_start(); // Start session here

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


include 'header.php'; 
?>

<div id="main-content">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <!-- post-container -->
                <div class="post-container">
                    <?php
                    $limit = 3;
                    if (isset($_GET['page'])) {
                        $page = $_GET['page'];
                    } else {
                        $page = 1;
                    }
                    
                    $offset = ($page - 1) * $limit;

                    // Query to fetch posts with pagination
                    $sql = "SELECT post.post_id, post.title, post.description, post.post_date, post.author, 
                                   category.category_name, user.username, post.category, post.post_img 
                            FROM post 
                            LEFT JOIN category ON post.category = category.category_id
                            LEFT JOIN user ON post.author = user.user_id
                            ORDER BY post.post_id DESC 
                            LIMIT {$offset}, {$limit}";

                    $result = mysqli_query($conn, $sql) or die("Query Failed: " . mysqli_error($conn));
                    
                    if (mysqli_num_rows($result) > 0) {                      
                        while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                        <div class="post-content">
                            <div class="row">
                                <div class="col-md-4">
                                    <a class="post-img" href="single.php?id=<?php echo $row['post_id']; ?>">
                                        <img src="admin/upload/<?php echo $row['post_img']; ?>" alt=""/>
                                    </a>
                                </div>
                                <div class="col-md-8">
                                    <div class="inner-content clearfix">
                                        <h3>
                                            <a href='single.php?id=<?php echo $row['post_id']; ?>'>
                                                <?php echo $row['title']; ?>
                                            </a>
                                        </h3>
                                        <div class="post-information">
                                            <span>
                                                <i class="fa fa-tags" aria-hidden="true"></i>
                                                <a href='category.php?cid=<?php echo $row['category']; ?>'>
                                                    <?php echo $row['category_name']; ?>
                                                </a>
                                            </span>
                                            <span>
                                                <i class="fa fa-user" aria-hidden="true"></i>
                                                <a href='author.php?aid=<?php echo $row['author']; ?>'>
                                                    <?php echo $row['username']; ?>
                                                </a>
                                            </span>
                                            <span>
                                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                                <?php echo $row['post_date']; ?>
                                            </span>
                                        </div>
                                        <p class="description">
                                            <?php echo substr($row['description'], 0, 130) . "..."; ?>
                                        </p>
                                        <a class='read-more pull-right' href='single.php?id=<?php echo $row['post_id']; ?>'>
                                            read more
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php 
                        }
                    } else {
                        echo "<h2>No Record Found.</h2>";
                    }
                    
                    // Pagination logic
                    $sql = "SELECT * FROM post";
                    $result = mysqli_query($conn, $sql) or die("Query Failed: " . mysqli_error($conn));

                    if (mysqli_num_rows($result) > 0) {
                        $total_records = mysqli_num_rows($result);
                        $total_page = ceil($total_records / $limit);
                        echo '<ul class="pagination admin-pagination">';
                        if ($page > 1) {
                            echo '<li><a href="index.php?page=' . ($page - 1) . '">Prev</a></li>'; 
                        }
                        for ($i = 1; $i <= $total_page; $i++) {
                            $active = ($i == $page) ? "active" : "";
                            echo '<li class="' . $active . '"><a href="index.php?page=' . $i . '">' . $i . '</a></li>';
                        }
                        if ($total_page > $page) {
                            echo '<li><a href="index.php?page=' . ($page + 1) . '">Next</a></li>';
                        }
                        echo '</ul>';
                    } 
                    ?>
                </div>
            </div>
            <?php include 'sidebar.php'; ?>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
